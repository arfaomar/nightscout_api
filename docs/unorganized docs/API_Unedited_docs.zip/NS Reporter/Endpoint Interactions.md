- uses NS APIv1

The `NightscoutService` class in this project is designed to interact with the Nightscout API, primarily to fetch and process data related to diabetes management. Below is a detailed documentation of how it interacts with each endpoint of the Nightscout API:

---

### **Endpoints and Their Interaction**

#### **1. `status.json`**
- **Description**: Fetches the status of the Nightscout server.
- **Usage**:
  - Checks if the server is reachable by requesting `status.json`.
  - Parses the response into a `StatusData` object to determine server status.
- **Code Example**:
  ```typescript
  const url = user.apiUrl(null, 'status.json', { reqParams: reqParams });
  const content = await this.ds.requestJson(url, reqParams);
  user.status = content != null ? StatusData.fromJson(content) : null;
  ```
- **Purpose**:
  - To verify the server's availability and fetch metadata about its status.

---

#### **2. `profiles.json`**
- **Description**: Retrieves profile data for a specific time range. (doesn't rely on the filtering via url)
- **Usage**:
  - Fetches user profiles using parameters like `count` and `startDate`.
  - Parses the response into `ProfileData` objects, which are then processed and sorted.
- **Code Example**:
  ```typescript
  let url = urlData.fullUrl('profile.json', `count=${maxCount}`);
  const content = await this.ds.requestJson(url, reqParams);
  for (const entry of content) {
    const profile = ProfileData.fromJson(entry, true);
    data.profiles.push(profile);
  }
  ```
- **Purpose**:
  - To retrieve basal rates, carbohydrate ratios, and sensitivity settings stored in user profiles.

---

#### **3. `treatments.json`**
- **Description**: Retrieves treatment data such as bolus, basal, and meal entries.
- **Usage**:
    - Fetches treatments for specific days using `created_at` parameters.
    - Filters treatments like `Profile Switch`, `Temp Basal`, `exercise`, and `BG Check`.
    - Parses treatments into `TreatmentData` objects.
    - **Special Case - Profile Switch**:
        - A "Profile Switch" event is included in the treatments data but serves as an indicator of profile parameter changes (e.g., basal rates, target glucose levels).
        - The application processes these switches to adjust the active profile for calculations, rather than treating them as direct actions like insulin delivery.
- **Code Example**:
  ```typescript
  const url = data.user.apiUrl(urlDate, 'treatments.json', {
    params: `find[created_at][$gte]=${profileBeg.toISOString()}&find[created_at][$lte]=${profileEnd.toISOString()}&count=100000`,
    reqParams: reqParams
  });
  const src = await this.ds.requestJson(url, reqParams);
  for (const treatment of src) {
    const t = TreatmentData.fromJson(treatment);
    data.ns.treatments.push(t);
  }
  ```
- **Purpose**:
    - To gather data related to insulin delivery, carbohydrate intake, and other treatments for analysis and reporting.
    - To track and process "Profile Switch" events for updating the active profile parameters.



---

#### **4. `entries.json`**
- **Description**: Retrieves Continuous Glucose Monitoring (CGM) entries for a specific time range.
- **Usage**:
  - Fetches CGM entries with `date` range parameters.
  - Parses entries into `EntryData` objects and processes them for gaps, duplicates, and interpolation.
- **Code Example**:
  ```typescript
  const url = GlobalsData.user.apiUrl(urlDate, 'entries.json', {
    params: `find[date][$gte]=${beg.getTime()}&find[date][$lte]=${end.getTime()}&count=100000`,
    reqParams: reqParams
  });
  const src = await this.ds.requestJson(url, reqParams);
  for (const entry of src) {
    const e = EntryData.fromJson(entry);
    data.ns.entries.push(e);
  }
  ```
- **Purpose**:
  - To retrieve glucose data points for use in daily analysis, visualizations, and reports.

---

#### **5. `devicestatus.json`**
- **Description**: Retrieves device status information for a specific time range.
- **Usage**:
  - Fetches device status updates using `created_at` range parameters.
  - Parses the response into `DeviceStatusData` objects.
- **Code Example**:
  ```typescript
  const url = data.user.apiUrl(urlDate, 'devicestatus.json', {
    params: `find[created_at][$gte]=${profileBeg.toISOString()}&find[created_at][$lte]=${profileEnd.toISOString()}&count=100000`,
    reqParams: reqParams
  });
  const src = await this.ds.requestJson(url, reqParams);
  for (const devicestatus of src) {
    data.ns.devicestatusList.push(DeviceStatusData.fromJson(devicestatus));
  }
  ```
- **Purpose**:
  - To monitor and analyze device-related data, such as battery levels, connectivity, and other metrics.

---

#### **6. `activity.json`**
- **Description**: Retrieves activity data for a specific time range.
- **Usage**:
  - Fetches activity data using `created_at` range parameters.
  - Parses the response into `ActivityData` objects.
- **Code Example**:
  ```typescript
  const url = data.user.apiUrl(urlDate, 'activity.json', {
    params: `find[created_at][$gte]=${profileBeg.toISOString()}&find[created_at][$lte]=${profileEnd.toISOString()}&count=100000`,
    reqParams: reqParams
  });
  const src = await this.ds.requestJson(url, reqParams);
  for (const activity of src) {
    const value = ActivityData.fromJson(activity);
    data.ns.activityList.push(value);
  }
  ```
- **Purpose**:
  - To gather information about physical activities and their impact on glucose levels and treatments.

---

### **General Interaction Flow**
1. **URL Construction**:
   - Uses helper functions like `apiUrl` to construct URLs for different endpoints.
   - Adds query parameters dynamically based on the type of data being fetched.

2. **Fetching Data**:
   - Sends HTTP requests using the `DataService` class (`ds.requestJson`).
   - Handles errors gracefully, such as logging when data cannot be fetched.

3. **Processing Data**:
   - Converts raw JSON responses into specific data models (e.g., `StatusData`, `ProfileData`).
   - Applies filters, sorts data, and performs calculations as necessary.

4. **Integration**:
   - Combines data from multiple endpoints into a cohesive structure (`ReportData`).
   - Uses this data for generating reports, charts, and user notifications.

---

### **Key Features and Notes**
- **Error Handling**:
  - Implements error messages and fallbacks, such as retrying with different parameters or showing warnings to users.

- **Localization**:
  - Uses `$localize` to provide user-friendly, localized error messages and progress updates.

- **Data Validation**:
  - Ensures that fetched data is valid and fits the expected structure before processing.

- **Optimization**:
  - Reduces redundant API calls by caching and reusing data where possible.