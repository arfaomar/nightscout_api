
---

### **1. StatusData**

**File:** [status-data.ts](https://github.com/zreptil/nightscout-reporter-angular/blob/117b541417d96058ac39983ef94fa6caa012ec76/src/app/_model/nightscout/status-data.ts)

- **Purpose:** Represents the status of the Nightscout server, including settings and extended settings.
- **Key Properties:** 
  - `status`, `name`, `version`, `serverTime`, `apiEnabled`, `careportalEnabled`, `boluscalcEnabled`.
  - Objects: `SettingsData`, `ExtendedSettingsData`.
- **Processing:** 
  - `fromJson(json: any)` converts raw JSON into a `StatusData` object with nested settings objects.

---

### **2. ProfileData**

**File:** [profile-data.ts](https://github.com/zreptil/nightscout-reporter-angular/blob/117b541417d96058ac39983ef94fa6caa012ec76/src/app/_model/nightscout/profile-data.ts)

- **Purpose:** Represents user profiles, including glucose targets and time-based profile entries.
- **Key Properties:** 
  - `id`, `defaultProfile`, `units`, `createdAt`, `duration`, `store` (mapped to `ProfileStoreData`).
- **Processing:** 
  - `fromJson(json: any)` processes the raw JSON into a `ProfileData` object, including its `store` structure.

---

### **3. TreatmentData**

**File:** [treatment-data.ts](https://github.com/zreptil/nightscout-reporter-angular/blob/117b541417d96058ac39983ef94fa6caa012ec76/src/app/_model/nightscout/treatment-data.ts)

- **Purpose:** Represents treatments, such as insulin doses, glucose corrections, and temporary targets.
- **Key Properties:** 
  - `eventType`, `duration`, `insulin`, `glucose`, `carbs`, `targetTop`, `targetBottom`.
  - Includes nested `InsulinInjectionData` and `BoluscalcData`.
- **Processing:** 
  - `fromJson(json: any)` converts JSON objects into a `TreatmentData` object, handling multiple types of treatments and entries.

---

### **4. EntryData**

**File:** [entry-data.ts](https://github.com/zreptil/nightscout-reporter-angular/blob/117b541417d96058ac39983ef94fa6caa012ec76/src/app/_model/nightscout/entry-data.ts)

- **Purpose:** Represents individual blood glucose entries or sensor readings.
- **Key Properties:** 
  - `time`, `rssi`, `sgv`, `mbg`, `type`, `slope`, `intercept`.
- **Processing:** 
  - `fromJson(json: any)` parses raw JSON data into an `EntryData` object with calculations for glucose values.

---

### **5. DeviceStatusData**

**File:** [device-status-data.ts](https://github.com/zreptil/nightscout-reporter-angular/blob/117b541417d96058ac39983ef94fa6caa012ec76/src/app/_model/nightscout/device-status-data.ts)

- **Purpose:** Represents the status of a device interacting with Nightscout, like a pump or uploader.
- **Key Properties:** 
  - `device`, `createdAt`, `openAPS`, `loop`, `pump`, `uploader`, `xdripjs`.
- **Processing:** 
  - `fromJson(json: any)` initializes `DeviceStatusData` from JSON, mapping nested objects like `LoopData` and `PumpData`.

---

### **6. ActivityData**

**File:** [activity-data.ts](https://github.com/zreptil/nightscout-reporter-angular/blob/117b541417d96058ac39983ef94fa6caa012ec76/src/app/_model/nightscout/activity-data.ts)

- **Purpose:** Tracks physical activities such as steps or heart rate.
- **Key Properties:** 
  - `createdAt`, `type`, `steps`, `bpm`, `accuracy`.
- **Processing:** 
  - `fromJson(json: any)` creates an `ActivityData` object from JSON, including basic validation and comparisons.