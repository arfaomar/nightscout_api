- Auth:
**Request**
```shell
curl --request GET \
  --url https://ns.jensheuschkel.de/api/v2/authorization/request/token=<admin-token>
```

**Response:** contains JWT Token used as a Bearer token to Authorise other API Requests
example:

```json
{
  "token": "abc123",
  "sub": "admin",
  "permissionGroups": [
    [
      "*"
    ],
    []
  ],
  "iat": 1744784812,
  "exp": 1744813612
}
```

---
#### Anmerkung

**GET filter_parameter gehen nicht!**
- Wenn ich direkt in der NS APP einen Eintrag erstelle, wird das nirgends angezeigt