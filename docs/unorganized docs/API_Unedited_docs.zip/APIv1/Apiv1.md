### Find syntax

Swagger writes "find=\[INPUT\]" into the URL, but the following examples are right:  
"find\[created_at\]\[$gt\]=2017-11-22Z"  
"find\[dateString\]\[$gte\]=2015-08-27"

---

### Debug

GET [/echo/{storage}/{spec}](https://ns.jensheuschkel.de/api-docs/#/Debug/get_echo__storage___spec_)

```json
{
  "query": {
    "type": "sgv",
    "created_at": {
      "$gte": "2025-04-26T11:27:05.546Z"
    }
  },
  "input": {
    "token": "admin-###############",
    "find": {
      "type": "sgv"
    }
  },
  "params": {
    "echo": "treatments",
    "model": "sgv"
  },
  "storage": "treatments"
}
```

GET [/times/echo/{prefix}/{regex}](https://ns.jensheuschkel.de/api-docs/#/Debug/get_times_echo__prefix___regex_)

```json
{
  "req": {
    "params": {
      "prefix": "ss",
      "regex": "ss"
    },
    "query": {
      "token": "admin-###############",
      "find": {
        "dateString": {
          "$in": [
            {}
          ],
          "$regex": {}
        }
      }
    }
  },
  "pattern": [
    ".*ss"
  ]
}
```
