# Treatments

id is MongoDB ObjectID see [Entries.md](https://nx55641.your-storageshare.de/f/554265) for more details.

**Schema:**

| Field         | Type   | Required | Description                                         |
| ------------- | ------ | -------- | --------------------------------------------------- |
| \_id          | string | Yes      | Internally assigned ID                              |
| eventType     | string | Yes      | The type of treatment event                         |
| created_at    | string | Yes      | The date of the event, might be set retroactively   |
| glucose       | string | No       | Current glucose                                     |
| glucoseType   | string | No       | Method used to obtain glucose, `Finger` or `Sensor` |
| carbs         | number | No       | Amount of carbs consumed in grams                   |
| protein       | number | No       | Amount of protein consumed in grams                 |
| fat           | number | No       | Amount of fat consumed in grams                     |
| insulin       | number | No       | Amount of insulin, if any                           |
| units         | string | No       | The units for the glucose value, `mg/dl` or `mmol`  |
| transmitterId | string | No       | The transmitter ID of the transmitter being started |
| sensorCode    | string | No       | The code used to start a Dexcom G6 sensor           |
| notes         | string | No       | Description/notes of treatment                      |
| enteredBy     | string | No       | Who entered the treatment                           |

- GET [/treatments](https://ns.jensheuschkel.de/api-docs/#/Treatments/get_treatments)  
  Response format:

```json
[
  {
    "_id": "6811e16bcaceb417dcd511be",
    "eventType": "Snack Bolus",
    "glucose": 23,
    "glucoseType": "Finger",
    "carbs": 55,
    "protein": "44",
    "fat": "66",
    "insulin": 6,
    "units": "mg/dl",
    "created_at": "2025-04-30T08:38:00.635Z",
    "utcOffset": 0
  }
]
```

- POST [/treatments](https://ns.jensheuschkel.de/api-docs/#/Treatments/addTreatments)  
  Request Format:

```json
[
  {
    "_id": "string",
    "eventType": "string",
    "created_at": "string",
    "glucose": "string",
    "glucoseType": "string",
    "carbs": 0,
    "protein": 0,
    "fat": 0,
    "insulin": 0,
    "units": "string",
    "transmitterId": "string",
    "sensorCode": "string",
    "notes": "string",
    "enteredBy": "string"
  }
]
```

- DELETE [/treatments](https://ns.jensheuschkel.de/api-docs/#/Treatments/remove)  
  Delete treatments matching query, same search syntax as GET.
- DELETE [/treatments/{spec}](https://ns.jensheuschkel.de/api-docs/#/Treatments/delete_treatments__spec_)  
  Delete treatments record with id provided in spec