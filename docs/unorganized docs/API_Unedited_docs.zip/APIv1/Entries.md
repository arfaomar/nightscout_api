# Entries

**Schema:**

| Field      | Type   | Required | Description                                                     |
|------------|--------|----------|-----------------------------------------------------------------|
| type       | string | Yes      | sgv, mbg, cal, etc                                              |
| dateString | string | Yes      | MUST be ISO 8601 format date parseable by JavaScript `Date()`     |
| date       | number | Yes      | Epoch timestamp                                                 |
| sgv        | number | No       | The glucose reading (only available for `sgv` types)              |
| direction  | string | No       | Direction of glucose trend reported by CGM (only for `sgv` types) |
| noise      | number | No       | Noise level at time of reading (only for `sgv` types)             |
| filtered   | number | No       | Raw filtered value from CGM transmitter (only for `sgv` types)    |
| unfiltered | number | No       | Raw unfiltered value from CGM transmitter (only for `sgv` types)  |
| rssi       | number | No       | Signal strength from CGM transmitter (only for `sgv` types)       |

- GET [/entries/{spec}](https://ns.jensheuschkel.de/api-docs/#/Entries/get_entries__spec_)

  The Entries endpoint returns information about the Nightscout entries

  **Requires** spec which can be:
  - An identifier (MongoDB ObjectId, 12 Byte, 24 Char hex string)
    - **4 bytes**: Unix timestamp in seconds (from epoch) – provides an approximate creation time.
    - **5 bytes**: Random value unique to the machine and process.
    - **3 bytes**: Incrementing counter, initialized to a random value.
  - filter:
    - sgv
    - mbg
- GET [/slice/{storage}/{field}/{type}/{prefix}/{regex}](https://ns.jensheuschkel.de/api-docs/#/Entries/get_slice__storage___field___type___prefix___regex_)

  The Entries endpoint returns information about the Nightscout entries.

  Requires:
  - storage: Prefix to use in constructing a prefix-based regex, default is `entries` or you can use `treatments`
  - field: Name of the field to use Regex against in query object, default is `dateString`
  - type: The type field to search against, default is sgv.
  - prefix: Prefix to use in constructing a prefix-based regex.
  - regex: Tail part of regexp to use in expanding/construccting a query object. Regexp also has bash-style brace and glob expansion applied to it, creating ways to search for modal times of day, perhaps using something like this syntax: `T{15..17}:.*`, this would search for all records from 3pm to 5pm.
- GET [/echo/{storage}/{spec}](https://ns.jensheuschkel.de/api-docs/#/Entries/get_echo__storage___spec_)

  Information about the mongo query object created by the query.

  Requires:
  - Storage: `entries`, or `treatments` to select the storage layer.
  - spec: entry id, such as `55cf81bc436037528ec75fa5` or a type filter such as `sgv`, `mbg`, etc. This parameter is optional.
- GET [/times/echo/{prefix}/{regex}](https://ns.jensheuschkel.de/api-docs/#/Entries/get_times_echo__prefix___regex_)

  Echo debug information about the query object constructed.

  Requires:
  - prefix: Prefix to use in constructing a prefix-based regex.
  - regex: Tail part of regexp to use in expanding/construccting a query object. Regexp also has bash-style brace and glob expansion applied to it, creating ways to search for modal times of day, perhaps using something like this syntax: `T{15..17}:.*`, this would search for all records from 3pm to 5pm.
- GET [/times/{prefix}/{regex}](https://ns.jensheuschkel.de/api-docs/#/Entries/get_times__prefix___regex_)

  The Entries endpoint returns information about the Nightscout entries.

  Requires:
  - prefix: Prefix to use in constructing a prefix-based regex.
  - regex: Tail part of regexp to use in expanding/construccting a query object. Regexp also has bash-style brace and glob expansion applied to it, creating ways to search for modal times of day, perhaps using something like this syntax: `T{15..17}:.*`, this would search for all records from 3pm to 5pm.
- GET [/entries](https://ns.jensheuschkel.de/api-docs/#/Entries/get_entries)  
  The Entries endpoint returns information about the Nightscout entries

  No requirements
- POST [/entries](https://ns.jensheuschkel.de/api-docs/#/Entries/get_entries)  
  Request body:

```json
[
  {
    "type": "string",
    "dateString": "string",
    "date": 0,
    "sgv": 0,
    "direction": "string",
    "noise": 0,
    "filtered": 0,
    "unfiltered": 0,
    "rssi": 0
  }
]
```

- DELETE [/entries](https://ns.jensheuschkel.de/api-docs/#/Entries/get_entries__spec_)  
  Remove multiple entries, same search syntax as GET.