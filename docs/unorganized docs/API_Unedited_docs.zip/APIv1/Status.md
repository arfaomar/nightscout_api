## Schema

_id is MongoDB ObjectID see [Entries.md](https://nx55641.your-storageshare.de/f/554265) for more details.

| Field             | Type       | Required | Description                                             |
| ----------------- | ---------- | -------- | ------------------------------------------------------- |
| \_id              | string     | Yes      | Internally assigned ID                                  |
| apiEnabled        | boolean    | No       | Whether or not the REST API is enabled.                 |
| careportalEnabled | boolean    | No       | Whether or not the careportal is enabled in the API.    |
| head              | string     | No       | The git identifier for the running instance of the app. |
| name              | string     | No       | Nightscout (static)                                     |
| version           | string     | No       | The version label of the app.                           |
| settings          | **object** | No       | -                                                       |
| extendedSettings  | **object** | No       | -                                                       |

**Settings:**

| Field                  | Type       | Required | Description                                                                             |
| ---------------------- | ---------- | -------- | --------------------------------------------------------------------------------------- |
| units                  | string     | No       | Default units for glucose measurements across the server.                               |
| timeFormat             | string     | No       | '12' or '24' - Default time format                                                      |
| customTitle            | string     | No       | Default custom title to be displayed system wide.                                       |
| nightMode              | boolean    | No       | Should Night mode be enabled by default?                                                |
| theme                  | string     | No       | Default theme to be displayed system wide, `default`, `colors`, `colorblindfriendly`.   |
| language               | string     | No       | Default language code to be used system wide                                            |
| showPlugins            | string     | No       | Plugins that should be shown by default                                                 |
| showRawbg              | string     | No       | If Raw BG is enabled when should it be shown? `never`, `always`, `noise`                |
| alarmTypes             | list       | No       | enum: List [ "simple", "predict" ]<br>Enabled alarm types, can be multiple              |
| alarmUrgentHigh        | boolean    | No       | Enable/Disable client-side Urgent High alarms by default, for use with `simple` alarms. |
| alarmHigh              | boolean    | No       | Enable/Disable client-side High alarms by default, for use with `simple` alarms.        |
| alarmLow               | boolean    | No       | Enable/Disable client-side Low alarms by default, for use with `simple` alarms.         |
| alarmUrgentLow         | boolean    | No       | Enable/Disable client-side Urgent Low alarms by default, for use with `simple` alarms.  |
| alarmTimeagoWarn       | boolean    | No       | Enable/Disable client-side stale data alarms by default.                                |
| alarmTimeagoWarnMins   | number     | No       | Number of minutes before a stale data warning is generated.                             |
| alarmTimeagoUrgent     | boolean    | No       | Enable/Disable client-side urgent stale data alarms by default.                         |
| alarmTimeagoUrgentMins | number     | No       | Number of minutes before a stale data warning is generated.                             |
| enable                 | list       | No       | Enabled features [string]                                                               |
| thresholds             | **object** | No       |                                                                                         |



### Status

GET [/status](https://ns.jensheuschkel.de/api-docs/#/Status/get_status) - Server side status, default settings and capabilities.

**Test:**
```json
{
  "status": "ok",
  "name": "nightscout",
  "version": "15.0.2",
  "serverTime": "2025-04-30T09:22:00.095Z",
  "serverTimeEpoch": 1746004920095,
  "apiEnabled": true,
  "careportalEnabled": true,
  "boluscalcEnabled": false,
  "settings": {
    "units": "mg/dl",
    "timeFormat": 12,
    "dayStart": 7,
    "dayEnd": 21,
    "nightMode": false,
    "editMode": true,
    "showRawbg": "never",
    "customTitle": "Nightscout",
    "theme": "default",
    "alarmUrgentHigh": true,
    "alarmUrgentHighMins": [
      30,
      60,
      90,
      120
    ],
    "alarmHigh": true,
    "alarmHighMins": [
      30,
      60,
      90,
      120
    ],
    "alarmLow": true,
    "alarmLowMins": [
      15,
      30,
      45,
      60
    ],
    "alarmUrgentLow": true,
    "alarmUrgentLowMins": [
      15,
      30,
      45
    ],
    "alarmUrgentMins": [
      30,
      60,
      90,
      120
    ],
    "alarmWarnMins": [
      30,
      60,
      90,
      120
    ],
    "alarmTimeagoWarn": true,
    "alarmTimeagoWarnMins": 15,
    "alarmTimeagoUrgent": true,
    "alarmTimeagoUrgentMins": 30,
    "alarmPumpBatteryLow": false,
    "language": "en",
    "scaleY": "log",
    "showPlugins": "dbsize delta direction upbat",
    "showForecast": "ar2",
    "focusHours": 3,
    "heartbeat": 60,
    "baseURL": "",
    "authDefaultRoles": "denied",
    "thresholds": {
      "bgHigh": 260,
      "bgTargetTop": 180,
      "bgTargetBottom": 80,
      "bgLow": 55
    },
    "insecureUseHttp": true,
    "secureHstsHeader": true,
    "secureHstsHeaderIncludeSubdomains": false,
    "secureHstsHeaderPreload": false,
    "secureCsp": false,
    "deNormalizeDates": false,
    "showClockDelta": false,
    "showClockLastTime": false,
    "frameUrl1": "",
    "frameUrl2": "",
    "frameUrl3": "",
    "frameUrl4": "",
    "frameUrl5": "",
    "frameUrl6": "",
    "frameUrl7": "",
    "frameUrl8": "",
    "frameName1": "",
    "frameName2": "",
    "frameName3": "",
    "frameName4": "",
    "frameName5": "",
    "frameName6": "",
    "frameName7": "",
    "frameName8": "",
    "authFailDelay": 5000,
    "adminNotifiesEnabled": true,
    "authenticationPromptOnLoad": false,
    "DEFAULT_FEATURES": [
      "bgnow",
      "delta",
      "direction",
      "timeago",
      "devicestatus",
      "upbat",
      "errorcodes",
      "profile",
      "bolus",
      "dbsize",
      "runtimestate",
      "basal",
      "careportal"
    ],
    "alarmTypes": [
      "predict"
    ],
    "enable": [
      "careportal",
      "rawbg",
      "iob",
      "treatmentnotify",
      "bgnow",
      "delta",
      "direction",
      "timeago",
      "devicestatus",
      "upbat",
      "errorcodes",
      "profile",
      "bolus",
      "dbsize",
      "runtimestate",
      "basal",
      "ar2"
    ]
  },
  "extendedSettings": {
    "devicestatus": {
      "advanced": true,
      "days": 1
    }
  },
  "authorized": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2Nlc3NUb2tlbiI6ImFkbWluLTJkN2YwZjEyNDFhMzNmNzQiLCJpYXQiOjE3NDYwMDQ5MjAsImV4cCI6MTc0NjAzMzcyMH0.KFlIQolVgqxFyhyabgLl75lGgvKnNxr4Vj3AZxD_hm4",
    "sub": "admin",
    "permissionGroups": [
      [
        "*"
      ],
      [
        "*:*:read"
      ],
      []
    ],
    "iat": 1746004920,
    "exp": 1746033720
  },
  "runtimeState": "loaded"
}
