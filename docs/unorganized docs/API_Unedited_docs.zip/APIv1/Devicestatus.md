## Schema

_id is MongoDB ObjectID see [Entries.md](https://nx55641.your-storageshare.de/f/554265) for more details.

| Field      | Type       | Required | Description                                          |
| ---------- | ---------- | -------- | ---------------------------------------------------- |
| \_id       | string     | Yes      | Internally assigned ID                               |
| device     | string     | Yes      | The type of treatment event                          |
| created_at | string     | Yes      | The date of the event, might be set retroactively    |
| openaps    | string     | No       | OpenAPS devicestatus record - TODO: Fill Out Details |
| loop       | string     | No       | Loop devicestatus record - TODO: Fill Out Details    |
| pump       | **object** | No       | -                                                    |
| uploader   | **object** | No       | -                                                    |
| xdripjs    | **object** | No       | -                                                    |

**Pump:**

| Field     | Type       | Required | Description                                   |
| --------- | ---------- | -------- | --------------------------------------------- |
| clock     | string     | No       | dateString, prefer ISO `8601`                 |
| battery   | **object** | No       | -                                             |
| reservoir | number     | No       | Amount of insulin remaining in pump reservoir |
| status    | **object** | No       | -                                             |

**Battery:**

| Field   | Type   | Required | Description                |
| ------- | ------ | -------- | -------------------------- |
| status  | string | No       | Pump Battery Status String |
| voltage | number | No       | Pump Battery Voltage Level |

**Status:**

| Field     | Type    | Required | Description                   |
| --------- | ------- | -------- | ----------------------------- |
| status    | string  | No       | Pump Status String            |
| bolusing  | boolean | No       | Is Pump Bolusing              |
| suspended | boolean | No       | Is Pump Suspended             |
| timestamp | string  | No       | dateString, prefer ISO `8601` |


**Uploader:**

| Field          | Type   | Required | Description                                         |
| -------------- | ------ | -------- | --------------------------------------------------- |
| batteryVoltage | number | No       | Uploader Device Battery Voltage                     |
| battery        | number | No       | Uploader Device Battery Percentage Charge Remaining |

**xdripjs:**

| Field               | Type   | Required | Description                                                      |
| ------------------- | ------ | -------- | ---------------------------------------------------------------- |
| state               | number | No       | CGM Sensor Session State Code                                    |
| stateString         | string | No       | CGM Sensor Session State String                                  |
| stateStringShort    | string | No       | CGM Sensor Session State Short String                            |
| txId                | string | No       | CGM Transmitter ID                                               |
| txStatus            | number | No       | CGM Transmitter Status                                           |
| txStatusString      | string | No       | CGM Transmitter Status String                                    |
| txStatusStringShort | string | No       | CGM Transmitter Status Short String                              |
| txActivation        | number | No       | CGM Transmitter Activation Milliseconds After Epoch              |
| mode                | string | No       | Mode xdrip-js Application Operationg: expired, not expired, etc. |
| timestamp           | number | No       | Last Update Milliseconds After Epoch                             |
| rssi                | number | No       | Receive Signal Strength of Transmitter                           |
| unfiltered          | number | No       | Most Recent Raw Unfiltered Glucose                               |
| filtered            | number | No       | Most Recent Raw Filtered Glucose                                 |
| noise               | number | No       | Calculated Noise Value - 1=Clean, 2=Light, 3=Medium, 4=Heavy     |
| noiseString         | number | No       | Noise Value String                                               |
| slope               | number | No       | Calibration Slope Value                                          |
| intercept           | number | No       | Calibration Intercept Value                                      |
| calType             | string | No       | Algorithm Used to Calculate Calibration Values                   |
| lastCalibrationDate | number | No       | Most Recent Calibration Milliseconds After Epoch                 |
| sessionStart        | number | No       | Sensor Session Start Milliseconds After Epoch                    |
| batteryTimestamp    | number | No       | Most Recent Batter Status Read Milliseconds After Epoch          |
| voltagea            | number | No       | Voltage of Battery A                                             |
| voltageb            | number | No       | Voltage of Battery B                                             |
| temperature         | number | No       | Transmitter Temperature                                          |
| resistance          | number | No       | Sensor Resistance                                                |


---
## Endpoints

GET [/devicestatus/](https://ns.jensheuschkel.de/api-docs/#/Devicestatus/get_devicestatus_) - All Device statuses matching query

```json
[
  {
    "_id": "68185e8d6f3e4c3b16ca87e2",
    "device": "testas",
    "created_at": "2025-05-05T06:45:33.209Z",
    "openaps": "string",
    "loop": "string",
    "pump": {
      "clock": "string",
      "battery": {
        "status": "string",
        "voltage": 0
      },
      "reservoir": 0,
      "status": {
        "status": "string",
        "bolusing": true,
        "suspended": true,
        "timestamp": "string"
      }
    },
    "uploader": {
      "batteryVoltage": 0,
      "battery": 0
    },
    "xdripjs": {
      "state": 0,
      "stateString": "string",
      "stateStringShort": "string",
      "txId": "string",
      "txStatus": 0,
      "txStatusString": "string",
      "txStatusStringShort": "string",
      "txActivation": 0,
      "mode": "string",
      "timestamp": 0,
      "rssi": 0,
      "unfiltered": 0,
      "filtered": 0,
      "noise": 0,
      "noiseString": 0,
      "slope": 0,
      "intercept": 0,
      "calType": "string",
      "lastCalibrationDate": 0,
      "sessionStart": 0,
      "batteryTimestamp": 0,
      "voltagea": 0,
      "voltageb": 0,
      "temperature": 0,
      "resistance": 0
    },
    "utcOffset": 120
  },
  {
    "_id": "68185e746f3e4ccc41ca87e1",
    "device": "test",
    ...
  },
  {
    "_id": "68185e646f3e4c48b7ca87e0",
    "device": "string",
	...
  }
]
```



POST [/devicestatus/](https://ns.jensheuschkel.de/api-docs/#/Devicestatus/addDevicestatuses) - Add new devicestatus records.

**Test** & Example:
```json
[
  {
    "device": "testas",
    "created_at": "string",
    "openaps": "string",
    "loop": "string",
    "pump": {
      "clock": "string",
      "battery": {
        "status": "string",
        "voltage": 0
      },
      "reservoir": 0,
      "status": {
        "status": "string",
        "bolusing": true,
        "suspended": true,
        "timestamp": "string"
      }
    },
    "uploader": {
      "batteryVoltage": 0,
      "battery": 0
    },
    "xdripjs": {
      "state": 0,
      "stateString": "string",
      "stateStringShort": "string",
      "txId": "string",
      "txStatus": 0,
      "txStatusString": "string",
      "txStatusStringShort": "string",
      "txActivation": 0,
      "mode": "string",
      "timestamp": 0,
      "rssi": 0,
      "unfiltered": 0,
      "filtered": 0,
      "noise": 0,
      "noiseString": 0,
      "slope": 0,
      "intercept": 0,
      "calType": "string",
      "lastCalibrationDate": 0,
      "sessionStart": 0,
      "batteryTimestamp": 0,
      "voltagea": 0,
      "voltageb": 0,
      "temperature": 0,
      "resistance": 0
    }
  }
]
```



DELETE [/devicestatus/](https://ns.jensheuschkel.de/api-docs/#/Devicestatus/delete_devicestatus_) - Delete all Devicestatus records matching query

Doesn't work because Swagger uses wrong Parameters:

is:
```bash
api/v1/devicestatus/?find=2015-08-27
```

should:
```bash
api/v1/devicestatus/?find[created_at][$gte]=2015-08-27
```

The "find"-parameter must not be empty either, otherwise the API will return a 502 code.

Example Return:
```json
{
  "n": 0,
  "optime": {
    "ts": "string",
    "t": 0
  },
  "electionId": "string",
  "ok": 0,
  "operationTime": "string",
  "$clusterTime": "string"
}
```



DELETE [/devicestatus/{spec}](https://ns.jensheuschkel.de/api-docs/#/Devicestatus/delete_devicestatus__spec_) - Delete devicestatus record with id provided in spec

Example return:
```json
{
  "n": 0,
  "optime": {
    "ts": "string",
    "t": 0
  },
  "electionId": "string",
  "ok": 0,
  "operationTime": "string",
  "$clusterTime": "string"
}
```

**Test**: /device/status/68185e8d6f3e4c3b16ca87e2

Actual return:
```json
{
  "result": {
    "n": 1,
    "ok": 1
  },
  "connection": {
    "_events": {},
    "_eventsCount": 4,
    "id": 4,
    "address": "172.18.0.5:27017",
    "bson": {},
    "socketTimeout": 0,
    "host": "mongo",
    "port": 27017,
    "monitorCommands": false,
    "closed": false,
    "destroyed": false,
    "helloOk": true,
    "lastIsMasterMS": 4
  },
  "n": 1,
  "ok": 1
}
```