## Schema

_id is MongoDB ObjectID see [Entries.md](https://nx55641.your-storageshare.de/f/554265) for more details.

| Field     | Type    | Required | Description            |
| --------- | ------- | -------- | ---------------------- |
| \_id      | string  | No       | Internally assigned ID |
| sens      | integer | No       | Internally assigned id |
| carbratio | integer | No       | Internally assigned id |
| carbs_hr  | integer | No       | Internally assigned id |


GET [/profile](https://ns.jensheuschkel.de/api-docs/#/Profile/get_profile)

```json
[
  {
    "_id": "6720024fbad952399da21981",
    "defaultProfile": "Tuned",
    "date": 1730150992266,
    "created_at": "2025-02-09T16:22:17.447Z",
    "startDate": "2024-10-28T21:29:00.000Z",
    "store": {
      "GLP-1": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 12
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 7
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 7
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 7
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 7
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 12
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "value": 50,
            "timeAsSeconds": 0
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.6
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.5
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.7
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.6
          },
          {
            "time": "04:00",
            "value": 1,
            "timeAsSeconds": 14400
          },
          {
            "time": "05:00",
            "value": 1,
            "timeAsSeconds": 18000
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.8
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 0.7
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 0.7
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 0.5
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 0.7
          },
          {
            "time": "11:00",
            "value": 1,
            "timeAsSeconds": 39600
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.5
          },
          {
            "time": "13:00",
            "value": 1.5,
            "timeAsSeconds": 46800
          },
          {
            "time": "14:00",
            "value": 1.5,
            "timeAsSeconds": 50400
          },
          {
            "time": "15:00",
            "value": 1.5,
            "timeAsSeconds": 54000
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.5
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.5
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 1.5
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 1.4
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 1
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 130,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 120
          },
          {
            "time": "23:00",
            "value": 130,
            "timeAsSeconds": 82800
          }
        ],
        "timezone": "Europe/Berlin",
        "carbs_hr": 20,
        "delay": 20,
        "startDate": "1970-01-01T00:00:00.000Z"
      },
      "WeekTune": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 7.159
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 81.60807909750305
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 48.964847458501836
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 81.60807909750305
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.717
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.647
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.751
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.833
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 0.722
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 0.747
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.936
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.362
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.234
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.269
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.381
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.494
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.674
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.554
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.601
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.287
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.338
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.546
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 2.264
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.534
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.599
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1.7
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1.202
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 0.721
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 105,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 105,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "timezone": "Europe/Berlin",
        "carbs_hr": 20,
        "delay": 20,
        "startDate": "1970-01-01T00:00:00.000Z",
        "units": "mg/dl"
      },
      "WeekEndTune": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 6.642
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 151.441
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.844
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.949
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 1.261
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 1.562
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 1.624
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 1.418
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 1.197
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.145
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.131
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.591
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.744
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.918
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.801
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.561
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.531
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.629
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.836
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.921
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.996
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.177
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.445
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 2.486
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 2.258
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 1.712
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 105,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 105,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "timezone": "Europe/Berlin",
        "carbs_hr": 20,
        "delay": 20,
        "startDate": "1970-01-01T00:00:00.000Z"
      },
      "Tuned": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 8
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 80
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 45
          },
          {
            "time": "22:00",
            "timeAsSeconds": 82800,
            "value": 80
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.5
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.6
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.7
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.9
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 0.7
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 0.7
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.7
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.9
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.1
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.1
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.3
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.5
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.5
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.4
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.1
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.2
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 2.1
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.3
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.6
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1.7
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1.3
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 0.7
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 105
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 105
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 110
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 110
          }
        ],
        "timezone": "Europe/Berlin",
        "carbs_hr": 20,
        "delay": 20,
        "startDate": "1970-01-01T00:00:00.000Z",
        "units": "mg/dl"
      }
    },
    "mills": 1730150992266,
    "srvModified": 1739118137447,
    "units": "mg/dl"
  },
  {
    "_id": "67121cfdbad952399da1fac6",
    "defaultProfile": "WeekTune",
    "date": 1729240318982,
    "created_at": "2024-10-18T08:31:58.9820000Z",
    "startDate": "2024-10-18T08:31:58.9820000Z",
    "store": {
      "GLP-1": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 12
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 7
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 7
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 7
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 7
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 12
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "value": 50,
            "timeAsSeconds": 0
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.6
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.5
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.7
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.6
          },
          {
            "time": "04:00",
            "value": 1,
            "timeAsSeconds": 14400
          },
          {
            "time": "05:00",
            "value": 1,
            "timeAsSeconds": 18000
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.8
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 0.7
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 0.7
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 0.5
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 0.7
          },
          {
            "time": "11:00",
            "value": 1,
            "timeAsSeconds": 39600
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.5
          },
          {
            "time": "13:00",
            "value": 1.5,
            "timeAsSeconds": 46800
          },
          {
            "time": "14:00",
            "value": 1.5,
            "timeAsSeconds": 50400
          },
          {
            "time": "15:00",
            "value": 1.5,
            "timeAsSeconds": 54000
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.5
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.5
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 1.5
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 1.4
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 1
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 130,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 120
          },
          {
            "time": "23:00",
            "value": 130,
            "timeAsSeconds": 82800
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      },
      "WeekTune": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 6.844
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 71.74439184806953
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 43.04663510884172
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 71.74439184806953
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.81
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.764
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.822
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.884
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 0.743
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 0.785
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.914
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.222
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.074
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.149
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.349
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.505
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.614
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.522
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.486
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.284
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.281
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.46
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 2.157
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.362
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.693
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1.672
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1.336
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 0.785
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 105,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 105,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      },
      "WeekEndTune": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 6.642
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 151.441
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.844
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.949
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 1.261
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 1.562
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 1.624
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 1.418
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 1.197
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.145
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.131
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.591
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.744
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.918
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.801
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.561
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.531
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.629
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.836
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.921
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.996
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.177
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.445
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 2.486
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 2.258
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 1.712
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 105,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 105,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      },
      "Tuned": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 6.985000000000001
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 70.492
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 42.2952
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 70.492
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.657
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.6
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.732
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.933
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 0.806
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 0.746
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.81
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.14
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.126
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.276
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.276
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.375
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.542
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.595
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.594
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.084
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.006
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.199
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 2.059
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.49
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.752
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1.687
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1.26
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 0.722
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 105
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 105
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 110
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 110
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      }
    }
  },
  {
    "_id": "670703e9bad952399da1e218",
    "defaultProfile": "WeekTune",
    "date": 1728513003573,
    "created_at": "2024-10-09T22:30:03.5730000Z",
    "startDate": "2024-10-09T22:30:03.5730000Z",
    "store": {
      "GLP-1": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 12
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 7
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 7
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 7
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 7
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 12
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "value": 50,
            "timeAsSeconds": 0
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.6
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.5
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.7
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.6
          },
          {
            "time": "04:00",
            "value": 1,
            "timeAsSeconds": 14400
          },
          {
            "time": "05:00",
            "value": 1,
            "timeAsSeconds": 18000
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.8
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 0.7
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 0.7
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 0.5
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 0.7
          },
          {
            "time": "11:00",
            "value": 1,
            "timeAsSeconds": 39600
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.5
          },
          {
            "time": "13:00",
            "value": 1.5,
            "timeAsSeconds": 46800
          },
          {
            "time": "14:00",
            "value": 1.5,
            "timeAsSeconds": 50400
          },
          {
            "time": "15:00",
            "value": 1.5,
            "timeAsSeconds": 54000
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.5
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.5
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 1.5
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 1.4
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 1
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 130,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 120
          },
          {
            "time": "23:00",
            "value": 130,
            "timeAsSeconds": 82800
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      },
      "WeekTune": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 6.990000000000001
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 76.45322057877814
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 45.871932347266885
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 76.45322057877814
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.653
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.599
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.71
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.886
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 0.735
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 0.749
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.812
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.159
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.096
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.208
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.211
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.334
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.523
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.541
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.533
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.049
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 0.978
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.195
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 2.167
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.541
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.823
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1.654
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1.27
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 0.692
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 105,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 105,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      },
      "WeekEndTune": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 6.642
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 151.441
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.844
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.949
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 1.261
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 1.562
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 1.624
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 1.418
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 1.197
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.145
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.131
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.591
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.744
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.918
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.801
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.561
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.531
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.629
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.836
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.921
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.996
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.177
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.445
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 2.486
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 2.258
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 1.712
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 105,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 105,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      },
      "Tuned": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 6.985000000000001
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 70.492
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 42.2952
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 70.492
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.657
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.6
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.732
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.933
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 0.806
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 0.746
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.81
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.14
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.126
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.276
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.276
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.375
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.542
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.595
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.594
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.084
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.006
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.199
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 2.059
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.49
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.752
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1.687
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1.26
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 0.722
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 105
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 105
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 110
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 110
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      }
    }
  },
  {
    "_id": "670703ecbad952399da1e21a",
    "defaultProfile": "WeekTune",
    "date": 1728513007007,
    "created_at": "2024-10-14T20:57:02.413Z",
    "startDate": "2024-10-09T22:30:00.000Z",
    "store": {
      "GLP-1": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 12
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 7
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 7
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 7
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 7
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 12
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "value": 50,
            "timeAsSeconds": 0
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.6
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.5
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.7
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.6
          },
          {
            "time": "04:00",
            "value": 1,
            "timeAsSeconds": 14400
          },
          {
            "time": "05:00",
            "value": 1,
            "timeAsSeconds": 18000
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.8
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 0.7
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 0.7
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 0.5
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 0.7
          },
          {
            "time": "11:00",
            "value": 1,
            "timeAsSeconds": 39600
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.5
          },
          {
            "time": "13:00",
            "value": 1.5,
            "timeAsSeconds": 46800
          },
          {
            "time": "14:00",
            "value": 1.5,
            "timeAsSeconds": 50400
          },
          {
            "time": "15:00",
            "value": 1.5,
            "timeAsSeconds": 54000
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.5
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.5
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 1.5
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 1.4
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 1
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 130,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 120
          },
          {
            "time": "23:00",
            "value": 130,
            "timeAsSeconds": 82800
          }
        ],
        "timezone": "Europe/Berlin",
        "carbs_hr": 20,
        "delay": 20,
        "startDate": "1970-01-01T00:00:00.000Z"
      },
      "WeekTune": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 7.096
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 79.12788330080515
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 47.47672998048309
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 79.12788330080515
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.644
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.589
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.684
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.85
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 0.672
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 0.746
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.808
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.178
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.077
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.159
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.156
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.3
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.507
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.494
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.484
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.02
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 0.952
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.192
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 2.264
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.598
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.89
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1.644
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1.295
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 0.676
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 105,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "22:00",
            "value": 105,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "22:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "timezone": "Europe/Berlin",
        "carbs_hr": 20,
        "delay": 20,
        "startDate": "1970-01-01T00:00:00.000Z",
        "units": "mg/dl"
      },
      "WeekEndTune": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 6.642
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 151.441
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.844
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.949
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 1.261
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 1.562
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 1.624
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 1.418
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 1.197
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.145
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.131
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.591
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.744
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.918
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.801
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.561
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.531
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.629
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.836
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.921
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.996
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.177
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.445
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 2.486
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 2.258
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 1.712
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 105,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 105,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "timezone": "Europe/Berlin",
        "carbs_hr": 20,
        "delay": 20,
        "startDate": "1970-01-01T00:00:00.000Z"
      },
      "Tuned": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 6.985000000000001
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 70.492
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 42.2952
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 70.492
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.657
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.6
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.732
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.933
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 0.806
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 0.746
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.81
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.14
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.126
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.276
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.276
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.375
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.542
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.595
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.594
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.084
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.006
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.199
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 2.059
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.49
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.752
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1.687
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1.26
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 0.722
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 105
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 105
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 110
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 110
          }
        ],
        "timezone": "Europe/Berlin",
        "carbs_hr": 20,
        "delay": 20,
        "startDate": "1970-01-01T00:00:00.000Z"
      }
    },
    "mills": 1728513007007,
    "srvModified": 1728939422413,
    "units": "mg/dl"
  },
  {
    "_id": "6706e605bad952399da1e1ce",
    "defaultProfile": "WeekTune",
    "date": 1728505352004,
    "created_at": "2024-10-09T20:22:32.0040000Z",
    "startDate": "2024-10-09T20:22:32.0040000Z",
    "store": {
      "GLP-1": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 12
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 7
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 7
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 7
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 7
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 12
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "value": 50,
            "timeAsSeconds": 0
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.6
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.5
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.7
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.6
          },
          {
            "time": "04:00",
            "value": 1,
            "timeAsSeconds": 14400
          },
          {
            "time": "05:00",
            "value": 1,
            "timeAsSeconds": 18000
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.8
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 0.7
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 0.7
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 0.5
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 0.7
          },
          {
            "time": "11:00",
            "value": 1,
            "timeAsSeconds": 39600
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.5
          },
          {
            "time": "13:00",
            "value": 1.5,
            "timeAsSeconds": 46800
          },
          {
            "time": "14:00",
            "value": 1.5,
            "timeAsSeconds": 50400
          },
          {
            "time": "15:00",
            "value": 1.5,
            "timeAsSeconds": 54000
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.5
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.5
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 1.5
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 1.4
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 1
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 130,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 120
          },
          {
            "time": "23:00",
            "value": 130,
            "timeAsSeconds": 82800
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      },
      "WeekTune": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 6.985000000000001
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 70.492
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 42.2952
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 70.492
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.657
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.6
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.732
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.933
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 0.806
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 0.746
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.81
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.14
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.126
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.276
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.276
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.375
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.542
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.595
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.594
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.084
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.006
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.199
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 2.059
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.49
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.752
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1.687
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1.26
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 0.722
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 105,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 105,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      },
      "WeekEndTune": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 6.642
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 151.441
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.844
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.949
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 1.261
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 1.562
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 1.624
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 1.418
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 1.197
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.145
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.131
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.591
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.744
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.918
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.801
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.561
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.531
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.629
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.836
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.921
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.996
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.177
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.445
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 2.486
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 2.258
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 1.712
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 105,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 105,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      },
      "Tuned": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 6.985000000000001
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 70.492
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 42.2952
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 70.492
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.657
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.6
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.732
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.933
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 0.806
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 0.746
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.81
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.14
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.126
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.276
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.276
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.375
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.542
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.595
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.594
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.084
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.006
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.199
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 2.059
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.49
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.752
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1.687
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1.26
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 0.722
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 105
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 105
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 110
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 110
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      }
    }
  },
  {
    "_id": "6706e5ffbad952399da1e1cd",
    "defaultProfile": "Tuned",
    "date": 1728505346079,
    "created_at": "2024-10-09T20:22:26.0790000Z",
    "startDate": "2024-10-09T20:22:26.0790000Z",
    "store": {
      "GLP-1": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 12
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 7
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 7
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 7
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 7
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 12
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "value": 50,
            "timeAsSeconds": 0
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.6
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.5
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.7
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.6
          },
          {
            "time": "04:00",
            "value": 1,
            "timeAsSeconds": 14400
          },
          {
            "time": "05:00",
            "value": 1,
            "timeAsSeconds": 18000
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.8
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 0.7
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 0.7
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 0.5
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 0.7
          },
          {
            "time": "11:00",
            "value": 1,
            "timeAsSeconds": 39600
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.5
          },
          {
            "time": "13:00",
            "value": 1.5,
            "timeAsSeconds": 46800
          },
          {
            "time": "14:00",
            "value": 1.5,
            "timeAsSeconds": 50400
          },
          {
            "time": "15:00",
            "value": 1.5,
            "timeAsSeconds": 54000
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.5
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.5
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 1.5
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 1.4
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 1
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 130,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 120
          },
          {
            "time": "23:00",
            "value": 130,
            "timeAsSeconds": 82800
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      },
      "WeekTune": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "value": 6
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "value": 50
          },
          {
            "time": "08:00",
            "value": 30
          },
          {
            "time": "23:00",
            "timeAsSeconds": 0,
            "value": 50
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.559
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.532
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.695
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.92
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 0.817
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 0.732
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.913
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.198
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.156
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.222
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.298
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.352
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.354
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.366
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.299
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.041
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.083
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.346
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.823
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.328
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.459
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1.595
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1.123
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 0.672
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 105,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 105,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      },
      "WeekEndTune": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 6.642
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 151.441
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.844
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.949
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 1.261
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 1.562
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 1.624
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 1.418
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 1.197
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.145
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.131
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.591
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.744
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.918
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.801
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.561
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.531
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.629
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.836
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.921
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.996
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.177
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.445
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 2.486
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 2.258
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 1.712
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 105,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 105,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      },
      "Tuned": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 6.985000000000001
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 70.492
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 42.2952
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 70.492
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.657
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.6
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.732
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.933
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 0.806
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 0.746
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.81
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.14
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.126
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.276
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.276
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.375
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.542
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.595
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.594
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.084
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.006
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.199
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 2.059
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.49
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.752
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1.687
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1.26
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 0.722
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 105
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 105
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 110
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 110
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      }
    }
  },
  {
    "_id": "6706e5c3bad952399da1e1cb",
    "defaultProfile": "Tuned",
    "date": 1728505283120,
    "created_at": "2024-10-09T20:21:23.1200000Z",
    "startDate": "2024-10-09T20:21:23.1200000Z",
    "store": {
      "GLP-1": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 12
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 7
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 7
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 7
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 7
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 12
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "value": 50,
            "timeAsSeconds": 0
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.6
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.5
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.7
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.6
          },
          {
            "time": "04:00",
            "value": 1,
            "timeAsSeconds": 14400
          },
          {
            "time": "05:00",
            "value": 1,
            "timeAsSeconds": 18000
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.8
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 0.7
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 0.7
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 0.5
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 0.7
          },
          {
            "time": "11:00",
            "value": 1,
            "timeAsSeconds": 39600
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.5
          },
          {
            "time": "13:00",
            "value": 1.5,
            "timeAsSeconds": 46800
          },
          {
            "time": "14:00",
            "value": 1.5,
            "timeAsSeconds": 50400
          },
          {
            "time": "15:00",
            "value": 1.5,
            "timeAsSeconds": 54000
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.5
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.5
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 1.5
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 1.4
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 1
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 130,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 120
          },
          {
            "time": "23:00",
            "value": 130,
            "timeAsSeconds": 82800
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      },
      "WeekTune": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "value": 6
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "value": 50
          },
          {
            "time": "08:00",
            "value": 30
          },
          {
            "time": "23:00",
            "timeAsSeconds": 0,
            "value": 50
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.559
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.532
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.695
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.92
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 0.817
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 0.732
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.913
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.198
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.156
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.222
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.298
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.352
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.354
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.366
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.299
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.041
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.083
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.346
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.823
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.328
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.459
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1.595
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1.123
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 0.672
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 105,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 105,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      },
      "WeekEndTune": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 6.642
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 151.441
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.844
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.949
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 1.261
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 1.562
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 1.624
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 1.418
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 1.197
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.145
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.131
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.591
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.744
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.918
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.801
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.561
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.531
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.629
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.836
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.921
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.996
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.177
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.445
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 2.486
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 2.258
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 1.712
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 105,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 105,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      },
      "Tuned": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 15.14
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 177.187
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.598
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.568
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.751
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.949
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 0.844
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 0.773
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.924
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.25
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.195
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.246
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.304
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.395
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.518
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.615
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.657
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.353
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.377
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.447
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.916
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.254
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.476
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1.635
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1.194
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 0.755
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 105
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 105
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 110
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 110
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      }
    }
  },
  {
    "_id": "6705b278bad952399da1def4",
    "defaultProfile": "WeekTune",
    "date": 1728426617613,
    "created_at": "2024-10-09T20:15:05.294Z",
    "startDate": "2024-10-08T22:30:00.000Z",
    "store": {
      "GLP-1": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 12
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 7
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 7
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 7
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 7
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 12
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "value": 50,
            "timeAsSeconds": 0
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.6
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.5
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.7
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.6
          },
          {
            "time": "04:00",
            "value": 1,
            "timeAsSeconds": 14400
          },
          {
            "time": "05:00",
            "value": 1,
            "timeAsSeconds": 18000
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.8
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 0.7
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 0.7
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 0.5
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 0.7
          },
          {
            "time": "11:00",
            "value": 1,
            "timeAsSeconds": 39600
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.5
          },
          {
            "time": "13:00",
            "value": 1.5,
            "timeAsSeconds": 46800
          },
          {
            "time": "14:00",
            "value": 1.5,
            "timeAsSeconds": 50400
          },
          {
            "time": "15:00",
            "value": 1.5,
            "timeAsSeconds": 54000
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.5
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.5
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 1.5
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 1.4
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 1
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 130,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 120
          },
          {
            "time": "23:00",
            "value": 130,
            "timeAsSeconds": 82800
          }
        ],
        "timezone": "Europe/Berlin",
        "carbs_hr": 20,
        "delay": 20,
        "startDate": "1970-01-01T00:00:00.000Z"
      },
      "WeekTune": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 6
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "value": 45
          },
          {
            "time": "08:00",
            "timeAsSeconds": 0,
            "value": 30
          },
          {
            "time": "22:00",
            "value": 45
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.584
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.558
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.721
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.956
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 0.847
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 0.749
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.938
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.245
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.199
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.25
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.31
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.346
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.348
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.365
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.268
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 0.97
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.023
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.34
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.822
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.282
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.416
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1.576
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1.117
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 0.706
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 105,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 105,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "timezone": "Europe/Berlin",
        "carbs_hr": 30,
        "delay": 20,
        "startDate": "1970-01-01T00:00:00.000Z",
        "units": "mg/dl"
      },
      "WeekEndTune": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 6.642
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 151.441
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.844
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.949
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 1.261
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 1.562
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 1.624
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 1.418
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 1.197
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.145
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.131
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.591
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.744
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.918
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.801
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.561
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.531
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.629
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.836
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.921
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.996
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.177
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.445
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 2.486
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 2.258
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 1.712
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 105,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 105,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "timezone": "Europe/Berlin",
        "carbs_hr": 20,
        "delay": 20,
        "startDate": "1970-01-01T00:00:00.000Z"
      }
    },
    "mills": 1728426617613,
    "srvModified": 1728504905294,
    "units": "mg/dl"
  },
  {
    "_id": "6705b27cbad952399da1def6",
    "defaultProfile": "WeekTune",
    "date": 1728426621587,
    "created_at": "2024-10-09T20:20:51.309Z",
    "startDate": "2024-10-08T22:30:00.000Z",
    "store": {
      "GLP-1": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 12
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 7
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 7
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 7
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 7
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 12
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "value": 50,
            "timeAsSeconds": 0
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.6
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.5
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.7
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.6
          },
          {
            "time": "04:00",
            "value": 1,
            "timeAsSeconds": 14400
          },
          {
            "time": "05:00",
            "value": 1,
            "timeAsSeconds": 18000
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.8
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 0.7
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 0.7
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 0.5
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 0.7
          },
          {
            "time": "11:00",
            "value": 1,
            "timeAsSeconds": 39600
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.5
          },
          {
            "time": "13:00",
            "value": 1.5,
            "timeAsSeconds": 46800
          },
          {
            "time": "14:00",
            "value": 1.5,
            "timeAsSeconds": 50400
          },
          {
            "time": "15:00",
            "value": 1.5,
            "timeAsSeconds": 54000
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.5
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.5
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 1.5
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 1.4
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 1
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 130,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 120
          },
          {
            "time": "23:00",
            "value": 130,
            "timeAsSeconds": 82800
          }
        ],
        "timezone": "Europe/Berlin",
        "carbs_hr": 20,
        "delay": 20,
        "startDate": "1970-01-01T00:00:00.000Z"
      },
      "WeekTune": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "value": 6
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "value": 50
          },
          {
            "time": "08:00",
            "value": 30
          },
          {
            "time": "23:00",
            "timeAsSeconds": 0,
            "value": 50
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.559
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.532
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.695
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.92
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 0.817
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 0.732
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.913
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.198
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.156
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.222
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.298
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.352
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.354
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.366
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.299
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.041
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.083
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.346
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.823
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.328
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.459
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1.595
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1.123
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 0.672
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 105,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 105,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "timezone": "Europe/Berlin",
        "carbs_hr": 40,
        "delay": 20,
        "startDate": "1970-01-01T00:00:00.000Z",
        "units": "mg/dl"
      },
      "WeekEndTune": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 6.642
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 151.441
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.844
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.949
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 1.261
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 1.562
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 1.624
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 1.418
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 1.197
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.145
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.131
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.591
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.744
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.918
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.801
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.561
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.531
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.629
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.836
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.921
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.996
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.177
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.445
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 2.486
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 2.258
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 1.712
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 105,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 105,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "timezone": "Europe/Berlin",
        "carbs_hr": 20,
        "delay": 20,
        "startDate": "1970-01-01T00:00:00.000Z"
      }
    },
    "mills": 1728426600000,
    "srvModified": 1728505251309,
    "units": "mg/dl"
  },
  {
    "_id": "67030f76bad952399da1d905",
    "defaultProfile": "WeekTune",
    "date": 1728253815497,
    "created_at": "2024-10-06T22:30:15.4970000Z",
    "startDate": "2024-10-06T22:30:15.4970000Z",
    "store": {
      "GLP-1": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 12
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 7
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 7
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 7
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 7
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 12
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "value": 50,
            "timeAsSeconds": 0
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.6
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.5
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.7
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 0.6
          },
          {
            "time": "04:00",
            "value": 1,
            "timeAsSeconds": 14400
          },
          {
            "time": "05:00",
            "value": 1,
            "timeAsSeconds": 18000
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 0.8
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 0.7
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 0.7
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 0.5
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 0.7
          },
          {
            "time": "11:00",
            "value": 1,
            "timeAsSeconds": 39600
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.5
          },
          {
            "time": "13:00",
            "value": 1.5,
            "timeAsSeconds": 46800
          },
          {
            "time": "14:00",
            "value": 1.5,
            "timeAsSeconds": 50400
          },
          {
            "time": "15:00",
            "value": 1.5,
            "timeAsSeconds": 54000
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.5
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.5
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 1.5
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 1.4
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 1
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 130,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 120
          },
          {
            "time": "23:00",
            "value": 130,
            "timeAsSeconds": 82800
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      },
      "WeekTune": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 18.953
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 152.27
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.63
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.601
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 0.773
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 1.019
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 0.911
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 0.803
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 1.015
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.343
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.295
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.294
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.328
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.34
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.351
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.372
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.229
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 0.946
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.02
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.301
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.786
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.195
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.342
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 1.537
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 1.117
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 0.756
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 105,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 105,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      },
      "WeekEndTune": {
        "dia": 6,
        "carbratio": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 6.642
          }
        ],
        "sens": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 151.441
          }
        ],
        "basal": [
          {
            "time": "00:00",
            "timeAsSeconds": 0,
            "value": 0.844
          },
          {
            "time": "01:00",
            "timeAsSeconds": 3600,
            "value": 0.949
          },
          {
            "time": "02:00",
            "timeAsSeconds": 7200,
            "value": 1.261
          },
          {
            "time": "03:00",
            "timeAsSeconds": 10800,
            "value": 1.562
          },
          {
            "time": "04:00",
            "timeAsSeconds": 14400,
            "value": 1.624
          },
          {
            "time": "05:00",
            "timeAsSeconds": 18000,
            "value": 1.418
          },
          {
            "time": "06:00",
            "timeAsSeconds": 21600,
            "value": 1.197
          },
          {
            "time": "07:00",
            "timeAsSeconds": 25200,
            "value": 1.145
          },
          {
            "time": "08:00",
            "timeAsSeconds": 28800,
            "value": 1.131
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 1.591
          },
          {
            "time": "10:00",
            "timeAsSeconds": 36000,
            "value": 1.744
          },
          {
            "time": "11:00",
            "timeAsSeconds": 39600,
            "value": 1.918
          },
          {
            "time": "12:00",
            "timeAsSeconds": 43200,
            "value": 1.801
          },
          {
            "time": "13:00",
            "timeAsSeconds": 46800,
            "value": 1.561
          },
          {
            "time": "14:00",
            "timeAsSeconds": 50400,
            "value": 1.531
          },
          {
            "time": "15:00",
            "timeAsSeconds": 54000,
            "value": 1.629
          },
          {
            "time": "16:00",
            "timeAsSeconds": 57600,
            "value": 1.836
          },
          {
            "time": "17:00",
            "timeAsSeconds": 61200,
            "value": 1.921
          },
          {
            "time": "18:00",
            "timeAsSeconds": 64800,
            "value": 1.996
          },
          {
            "time": "19:00",
            "timeAsSeconds": 68400,
            "value": 2.177
          },
          {
            "time": "20:00",
            "timeAsSeconds": 72000,
            "value": 2.445
          },
          {
            "time": "21:00",
            "timeAsSeconds": 75600,
            "value": 2.486
          },
          {
            "time": "22:00",
            "timeAsSeconds": 79200,
            "value": 2.258
          },
          {
            "time": "23:00",
            "timeAsSeconds": 82800,
            "value": 1.712
          }
        ],
        "target_low": [
          {
            "time": "00:00",
            "value": 105,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 90
          },
          {
            "time": "23:00",
            "value": 105,
            "timeAsSeconds": 82800
          }
        ],
        "target_high": [
          {
            "time": "00:00",
            "value": 110,
            "timeAsSeconds": 0
          },
          {
            "time": "09:00",
            "timeAsSeconds": 32400,
            "value": 110
          },
          {
            "time": "23:00",
            "value": 110,
            "timeAsSeconds": 82800
          }
        ],
        "units": "mg/dl",
        "timezone": "Europe/Berlin"
      }
    }
  }
]
```