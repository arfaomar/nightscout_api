#### Search

 GET https://ns.jensheuschkel.de/api/v3/treatments

```json
{
  "status": 200,
  "result": [
    {
      "eventType": "Temp Basal",
      "created_at": "2024-10-01T00:03:35.000Z",
      "enteredBy": "openaps://AndroidAPS",
      "isValid": true,
      "duration": 30,
      "durationInMilliseconds": 1800000,
      "type": "NORMAL",
      "rate": 0,
      "percent": -100,
      "pumpId": 3455482030799,
      "pumpType": "DANA_I",
      "identifier": "66fb3c59bad952399da1c7f8",
      "srvModified": 1727741015000,
      "srvCreated": 1727741015000
    },
    {
      "eventType": "Correction Bolus",
      "created_at": "2024-10-01T10:44:19.000Z",
      "date": 1727779459000,
      "insulin": 0.25,
      "type": "SMB",
      "isValid": true,
      "isSMB": true,
      "pumpId": 3455558918903,
      "pumpType": "DANA_I",
      "identifier": "66fbd28bbad952399da1c933",
      "srvModified": 1727779459000,
      "srvCreated": 1727779459000
    },
    {
      "eventType": "Meal Bolus",
      "created_at": "2024-10-01T12:15:47.000Z",
      "date": 1727784947000,
      "isValid": true,
      "carbs": 15,
      "notes": "",
      "identifier": "66fbe7f9bad952399da1c960",
      "srvModified": 1727784947000,
      "srvCreated": 1727784947000
    },
    {
      "eventType": "Temporary Target",
      "created_at": "2024-10-01T12:15:54.101Z",
      "timestamp": 1727784954101,
      "duration": 20,
      "durationInMilliseconds": 1214996,
      "isValid": true,
      "enteredBy": "AndroidAPS",
      "reason": "Hypo",
      "targetBottom": 140,
      "targetTop": 140,
      "units": "mg/dl",
      "identifier": "66fbe7f9bad952399da1c961",
      "srvModified": 1727784954101,
      "srvCreated": 1727784954101
    },
    {
      "eventType": "Announcement",
      "created_at": "2024-10-01T14:48:32.628Z",
      "enteredBy": "AAPS",
      "isValid": true,
      "notes": "Large time difference:\nTime in pump is off by more than 1.5 hours.\nPlease adjust the time manually on the pump and make sure that reading the history from the pump does not cause unexpected behaviour.\nIf possible, remove the history from the pump before changing the time or disable the closed loop for one DIA after the last wrong history entry but minimum one DIA from now.",
      "units": "mg/dl",
      "isAnnouncement": true,
      "identifier": "66fc0bbfbad952399da1c9aa",
      "srvModified": 1727794112628,
      "srvCreated": 1727794112628
    }
  ]
}

```

---
#### Read

GET  https://ns.jensheuschkel.de/api/v3/treatments/ `:identifier`

```json
{
  "status": 200,
  "result": {
    "created_at": "2024-10-01T00:03:35.000Z",
    "enteredBy": "openaps://AndroidAPS",
    "eventType": "Temp Basal",
    "isValid": true,
    "duration": 30,
    "durationInMilliseconds": 1800000,
    "type": "NORMAL",
    "rate": 0,
    "percent": -100,
    "pumpId": 3455482030799,
    "pumpType": "DANA_I",
    "identifier": "66fb3c59bad952399da1c7f8",
    "srvModified": 1727741015000,
    "srvCreated": 1727741015000
  }
}
```

```json
{
  "status": 200,
  "result": {
    "eventType": "Correction Bolus",
    "insulin": 0.35,
    "created_at": "2024-10-01T10:38:48.000Z",
    "date": 1727779128000,
    "type": "SMB",
    "isValid": true,
    "isSMB": true,
    "pumpId": 3455558256898,
    "pumpType": "DANA_I",
    "identifier": "66fbd13ebad952399da1c929",
    "srvModified": 1727779128000,
    "srvCreated": 1727779128000
  }
}
```

```json
{
  "status": 200,
  "result": {
    "eventType": "Meal Bolus",
    "carbs": 15,
    "notes": "",
    "created_at": "2024-10-01T12:15:47.000Z",
    "isValid": true,
    "date": 1727784947000,
    "identifier": "66fbe7f9bad952399da1c960",
    "srvModified": 1727784947000,
    "srvCreated": 1727784947000
  }
}
```

```json
{
  "status": 200,
  "result": {
    "eventType": "Temporary Target",
    "duration": 30,
    "durationInMilliseconds": 1800000,
    "isValid": true,
    "created_at": "2024-10-01T10:38:28.181Z",
    "timestamp": 1727779108181,
    "enteredBy": "AndroidAPS",
    "reason": "Automation",
    "targetBottom": 80,
    "targetTop": 80,
    "units": "mg/dl",
    "identifier": "66fbd123bad952399da1c926",
    "srvModified": 1727779108181,
    "srvCreated": 1727779108181
  }
}
```

```json
{
  "status": 200,
  "result": {
    "eventType": "Announcement",
    "isValid": true,
    "created_at": "2024-10-01T14:48:32.628Z",
    "enteredBy": "AAPS",
    "units": "mg/dl",
    "notes": "Pump unreachable",
    "isAnnouncement": true,
    "identifier": "66fc0bbfbad952399da1c9aa",
    "srvModified": 1727794112628,
    "srvCreated": 1727794112628
  }
}
```

---
#### Create

POST https://ns.jensheuschkel.de/api/v3/treatments
(Date can only exist once otherwise data gets overwritten!)

```json
{
	"date": 1745261261000,
	"app": "Test"
	// add any property you want
}
```


Schema:

| Field          | Type                 | Required/Auto | Example                                | Description                                              |
| -------------- | -------------------- | ------------- | -------------------------------------- | -------------------------------------------------------- |
| `identifier`   | `string`             | Auto          | `53409478-105f-11e9-ab14-d663bd873d93` | Server-generated unique ID for deduplication. Immutable. |
| `date`         | `int64` / `ISO 8601` | Required      | `1525383610088`                        | Timestamp of event. Stored in UTC. Immutable.            |
| `utcOffset`    | `integer`            | Optional      | `120`                                  | Local timezone offset in minutes. Auto or client-set.    |
| `app`          | `string`             | Required      | `xdrip`                                | Originating app/system. Immutable.                       |
| `device`       | `string`             | Optional      | `dexcom G5`                            | Originating device info. Immutable.                      |
| `_id`          | `string`             | Auto          | `58e9dfbc166d88cc18683aac`             | Internal MongoDB ID. Not used by clients.                |
| `srvCreated`   | `int64`              | Auto          | `1525383610088`                        | Server-side insertion timestamp. Immutable.              |
| `srvModified`  | `int64`              | Auto          | `1525383610088`                        | Server-side last modification timestamp. Immutable.      |
| `subject`      | `string`             | Auto          | `uploader`                             | Set from user token (JWT). Immutable.                    |
| `modifiedBy`   | `string`             | Auto          | `admin`                                | Last user to modify or delete. Immutable.                |
| `isValid`      | `boolean`            | Auto          | `false`                                | Only for deleted documents in history view. Immutable.   |
| `isReadOnly`   | `boolean`            | Optional      | `true`                                 | If `true`, document becomes immutable.                   |
| `eventType`    | `string`             | Required      | `Meal Bolus`, `Temp Basal`, etc.       | Type of treatment action. Immutable.                     |
| `glucose`      | `string`             | Optional      | —                                      | Current BG value.                                        |
| `glucoseType`  | `string`             | Optional      | `Sensor`, `Finger`                     | Method used to measure BG.                               |
| `units`        | `string`             | Recommended   | `mg/dl`, `mmol/l`                      | Unit for glucose. Recommended when using `glucose`.      |
| `carbs`        | `number`             | Optional      | —                                      | Carbohydrate amount.                                     |
| `protein`      | `number`             | Optional      | —                                      | Protein amount.                                          |
| `fat`          | `number`             | Optional      | —                                      | Fat amount.                                              |
| `insulin`      | `number`             | Optional      | —                                      | Insulin amount.                                          |
| `duration`     | `number`             | Optional      | —                                      | Duration (e.g., for temp basal).                         |
| `preBolus`     | `number`             | Optional      | —                                      | Minutes pre-meal bolus was given.                        |
| `splitNow`     | `number`             | Optional      | —                                      | Immediate % of combo bolus.                              |
| `splitExt`     | `number`             | Optional      | —                                      | Extended % of combo bolus.                               |
| `percent`      | `number`             | Optional      | —                                      | % change for basal adjustment.                           |
| `absolute`     | `number`             | Optional      | —                                      | Absolute basal change in U/h.                            |
| `targetTop`    | `number`             | Optional      | —                                      | Upper limit for temp BG target.                          |
| `targetBottom` | `number`             | Optional      | —                                      | Lower limit for temp BG target.                          |
| `profile`      | `string`             | Optional      | —                                      | Profile name if switching.                               |
| `reason`       | `string`             | Optional      | —                                      | Reason for action (e.g., for target or bolus).           |
| `notes`        | `string`             | Optional      | —                                      | Additional info about treatment.                         |
| `enteredBy`    | `string`             | Optional      | —                                      | Source of the entry (device, user, app).                 |


---
#### Update (full overwrite)

PUT https://ns.jensheuschkel.de/api/v3/treatments/{identifier}

```json
{
  "date": 1532936118000,
  "app": "xdrip"
  // any changes you wish to make
}
```

---

#### Patch (partial update)

PATCH https://ns.jensheuschkel.de/api/v3/treatments/{identifier}

```json
{
  "date": 1532936118000,
  "app": "xdrip"
  // any changes you wish to make
}
```

---

#### Delete

DELETE https://ns.jensheuschkel.de/api/v3/treatments/ `:identifier` /  `optional:permanent=true or false`