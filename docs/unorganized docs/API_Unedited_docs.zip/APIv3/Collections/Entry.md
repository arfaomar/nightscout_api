
---
#### Search 

GET https://ns.jensheuschkel.de/api/v3/entries

```json
{
	"device": "AAPS-Dexcom",
	"date": 1727833706000,
	"dateString": "2024-10-02T01:48:26.000Z",
	"isValid": true,
	"sgv": 121 | (~70-230),
	"direction": "Flat" | "FortyFiveDown" | "SingleDown" | "SingleUP" | "FortyFiveUp",
	"type": "sgv",
	"created_at": "2024-10-02T01:48:22.801Z",
	"identifier": "66fca666bad952399da1cafb",
	"srvModified": 1727833706000,
	"srvCreated": 1727833706000
}
```

---
#### Create

POST https://ns.jensheuschkel.de/api/v3/entries
(Date darf nur 1 Mal existieren!)

```json
{
	"date": 1745261261000,
	"app": "Test"
}
```

Schema:

| Field         | Type                  | Required          | Example                                   | Description                                                         |
| ------------- | --------------------- | ----------------- | ----------------------------------------- | ------------------------------------------------------------------- |
| `identifier`  | `string`              | No                | `53409478-105f-11e9-ab14-d663bd873d93`    | Server-assigned unique ID. Used for deduplication. Immutable.       |
| `date`        | `int64` or ISO string | Yes               | `1525383610088` or `2018-05-03T21:40:10Z` | Event timestamp, stored as UTC. Immutable.                          |
| `utcOffset`   | `integer`             | Optional          | `120`                                     | Timezone offset in minutes. Auto-set or client-provided. Immutable. |
| `app`         | `string`              | Yes               | `xdrip`                                   | Name of app or system that first recorded the data. Immutable.      |
| `device`      | `string`              | Optional          | `dexcom G5`                               | Origin device (can include serial number). Immutable.               |
| `_id`         | `string`              | Auto              | `58e9dfbc166d88cc18683aac`                | Internal database ID (not for external use).                        |
| `srvCreated`  | `int64`               | Auto              | `1525383610088`                           | Timestamp when inserted into DB. Immutable.                         |
| `srvModified` | `int64`               | Auto              | `1525383610088`                           | Timestamp of last modification. Immutable.                          |
| `subject`     | `string`              | Auto              | `uploader`                                | Creator of the document (from JWT). Immutable.                      |
| `modifiedBy`  | `string`              | Auto              | `admin`                                   | Last modifier (from patch/delete). Immutable.                       |
| `isValid`     | `boolean`             | Auto              | `false`                                   | False if deleted. Appears only in history view.                     |
| `isReadOnly`  | `boolean`             | Optional          | `true`                                    | Prevents all future modifications or deletions.                     |
| `type`        | `string`              | Yes               | `sgv`, `mbg`, `cal`, etc.                 | Event type (e.g., sensor glucose value or calibration).             |
| `sgv`         | `number`              | Depends on `type` | `140`                                     | Glucose reading. Present only for `sgv` type.                       |
| `direction`   | `string`              | Optional          | `"DoubleDown"`                            | Glucose trend (e.g., `"Flat"`, `"SingleUp"`). `sgv` type only.      |
| `noise`       | `number`              | Optional          | `1`                                       | Noise level from CGM. `sgv` type only.                              |
| `filtered`    | `number`              | Optional          | `157300`                                  | Filtered raw value from CGM. `sgv` type only.                       |
| `unfiltered`  | `number`              | Optional          | `158000`                                  | Unfiltered raw CGM value. `sgv` type only.                          |
| `rssi`        | `number`              | Optional          | `100`                                     | Signal strength from CGM device. `sgv` type only.                   |
| `units`       | `string`              | Recommended       | `"mg"`, `"mmol"`                          | Units of glucose (mg/dl or mmol/l). Strongly encouraged.            |

---
#### Read

GET https://ns.jensheuschkel.de/api/v3/entries/{identifier}

```json
{
	"status": 200,
	"result": 
	{
		"date": 1745261261000,
		"app": "Test",
		"utcOffset": 120,
		"created_at": "2025-04-21T18:47:41.000Z",
		"identifier": "f584435a-cf2c-542a-aa2b-d9c6562d3da6",
		"srvModified": 1745350582944,
		"srvCreated": 1745350582944,
		"subject": "admin"
	}
}
```

---
#### Update /{identifier}

PUT https://ns.jensheuschkel.de/api/v3/entries/ `:identifier`

```json
{
	"date": 1745261261000,
	"app": "test2",
	"test": "uploader"
}
```

Response:
```json
{
  "status": 400,
  "message": "Field app cannot be modified by the client"
}
```

Wie soll man das bearbeiten, wenn "app" pflicht ist aber man es nicht ändern darf?

---
#### Partially Update /{identifier}

Patch https://ns.jensheuschkel.de/api/v3/entries/ `:identifier`

Funktioniert wie vermutet.