
---
#### Search 

GET https://ns.jensheuschkel.de/api/v3/devicestatus

```json
{
  "status": 200,
  "result": [
    {
      "created_at": "2024-10-01T00:03:32.146Z",
      "device": "openaps://Google Pixel 7a",
      "identifier": "66fb3c54bad952399da1c7f7",
      "srvModified": 1727741012146,
      "srvCreated": 1727741012146,
      "uploaderBattery": 63,
      "isCharging": true,
      "pump": {
        "battery": {
          "percent": 25
        },
        "status": {
          "status": "normal",
          "timestamp": "2024-10-01T00:03:01.551Z"
        },
        "extended": {
          "Version": "3.2.0.2-1399944ced-2023.11.13",
          "LastBolus": "10/1/24 21:58",
          "LastBolusAmount": 0.05,
          "BaseBasalRate": 1.15,
          "ActiveProfile": "WeekTune"
        },
        "reservoir": 181,
        "clock": "2024-10-01T00:03:32.146Z"
      },
      "openaps": {
        "suggested": {
          "temp": "absolute",
          "bg": 74,
          "tick": "+0",
          "eventualBG": 136,
          "targetBG": 120,
          "insulinReq": 0,
          "rate": 0,
          "duration": 30,
          "reason": "COB: 0, Dev: -53, BGI: 6, ISF: 102...",
          "predBGs": {
            "IOB": [74, 74, 75, 77],
            // usually contains multiple predicted BG values
            "ZT": [74, 80, 87, 94]
            // same here — multi-point trend prediction
          }
        },
        "iob": {
          "iob": -1.225,
          "basaliob": -1.235,
          "activity": -0.0127,
          "time": "2024-10-01T00:03:32.145Z"
        }
      }
    }
  ] //  always an array, usually multiple entries over time
}
```

---
#### Create

POST https://ns.jensheuschkel.de/api/v3/devicestatus

```json
{
  "date": 1532936118000,
  "app": "brah"
}
```

Schema:

| Field           | Type          | Required/Auto | Example                                | Description                                                |
| --------------- | ------------- | ------------- | -------------------------------------- | ---------------------------------------------------------- |
| `identifier`    | `string`      | Auto          | `53409478-105f-11e9-ab14-d663bd873d93` | Unique document ID, assigned by server. Immutable.         |
| `date`          | `int64` / ISO | Required      | `1525383610088`                        | Event timestamp (stored in UTC). Immutable.                |
| `utcOffset`     | `integer`     | Optional      | `120`                                  | UTC offset in minutes, auto-parsed or provided. Immutable. |
| `app`           | `string`      | Required      | `xdrip`                                | Application or system that recorded the event. Immutable.  |
| `device`        | `string`      | Optional      | `dexcom G5`                            | Source device name or serial number. Immutable.            |
| `_id`           | `string`      | Auto          | `58e9dfbc166d88cc18683aac`             | Internal MongoDB ID (not for external use).                |
| `srvCreated`    | `int64`       | Auto          | `1525383610088`                        | Server-side timestamp when inserted. Immutable.            |
| `srvModified`   | `int64`       | Auto          | `1525383610088`                        | Server-side timestamp when last modified. Immutable.       |
| `subject`       | `string`      | Auto          | `uploader`                             | Identity of creator (set from JWT). Immutable.             |
| `modifiedBy`    | `string`      | Auto          | `admin`                                | Last editor/deleter. Immutable.                            |
| `isValid`       | `boolean`     | Auto          | `false`                                | Indicates deletion (only in history views). Immutable.     |
| `isReadOnly`    | `boolean`     | Optional      | `true`                                 | If true, the document is permanently immutable.            |
| `some_property` | `string`      | Optional      | —                                      | Placeholder for additional properties.                     |


---
#### Read

GET https://ns.jensheuschkel.de/api/v3/devicestatus/{identifier}

```json
{
  "status": 200,
  "result": {
    "date": 1532936118000,
    "app": "brah",
    "utcOffset": 120,
    "created_at": "2018-07-30T07:35:18.000Z",
    "identifier": "d6bb50c7-cf6e-5e6b-8d53-7ce1db063497",
    "srvModified": 1745358115221,
    "srvCreated": 1745358115221,
    "subject": "admin"
  }
}
```

---
#### Update /{identifier}

PUT https://ns.jensheuschkel.de/api/v3/devicestatus/{identifier}

```json
{
	"date": 1745261261000,
	"app": "test2",
	"test": "uploader"
}
```

Response:
```json
{
  "status": 400,
  "message": "Field app cannot be modified by the client"
}
```

Wie soll man das bearbeiten, wenn "app" pflicht ist aber man es nicht ändern darf?
PS: app sowie Date sind pflicht, jedoch nicht änderbar!

---
#### Partially Update /{identifier}

PATCH https://ns.jensheuschkel.de/api/v3/devicestatus/{identifier}

Funktioniert wie vermutet.