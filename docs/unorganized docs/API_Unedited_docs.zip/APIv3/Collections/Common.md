
#### History GMT


- **Format:** Mon, 20 Apr 2025 18:47:49 GMT
GET  https://ns.jensheuschkel.de/api/v3//{collection}/history/
```bash
-H 'Last-Modified: Mon, 20 Apr 2025 18:47:49 GMT'
```

---
#### History UNIX

- **Format:** 1727807935000
GET https://ns.jensheuschkel.de/api/v3//{collection}/history/{lastModified}
```bash
-H 'Last-Modified: 1727807935000'
```

---
#### Version

Respone:
```json
{
  "status": 200,
  "result": {
    "version": "15.0.2",
    "apiVersion": "3.0.3-alpha",
    "srvDate": 1745360436737,
    "storage": {
      "storage": "mongodb",
      "version": "4.4.29"
    }
  }
}
```


---
#### Status

Respone:
```json
{
  "status": 200,
  "result": {
    "version": "15.0.2",
    "apiVersion": "3.0.3-alpha",
    "srvDate": 1745360446363,
    "storage": {
      "storage": "mongodb",
      "version": "4.4.29"
    },
    "apiPermissions": {
      "devicestatus": "crud",
      "entries": "crud",
      "food": "crud",
      "profile": "crud",
      "settings": "crud",
      "treatments": "crud"
    }
  }
}
```

---
#### Last Modified

Respone:
```json
{
  "status": 200,
  "result": {
    "srvDate": 1745360456233,
    "collections": {
      "devicestatus": 1745358115221,
      "entries": 1745353237650,
      "profile": 1745352478248,
      "settings": 1745353933726,
      "treatments": 1745353777527
    }
  }
}
```