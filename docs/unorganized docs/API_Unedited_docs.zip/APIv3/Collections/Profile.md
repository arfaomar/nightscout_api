
---
#### Search

 GET https://ns.jensheuschkel.de/api/v3/profile

```json
{
  "defaultProfile": "WeekTune",
  "date": 1727821804761,
  "created_at": "2024-10-01T22:30:04.761Z",
  "startDate": "2024-10-01T22:30:04.761Z",
  "store": {
    "WeekTune": {
      "dia": 6,
      "carbratio": [
        {
          "time": "00:00",
          "timeAsSeconds": 0,
          "value": 14.574
        }
        // usually only 1 entry, but can have more
      ],
      "sens": [
        {
          "time": "00:00",
          "timeAsSeconds": 0,
          "value": 121.893
        }
        // can be 1 or more depending on profile tuning
      ],
      "basal": [
        {
          "time": "00:00",
          "timeAsSeconds": 0,
          "value": 0.772
        },
        {
          "time": "01:00",
          "timeAsSeconds": 3600,
          "value": 0.923
        }
        // usually 24 entries (1 per hour)
      ],
      "target_low": [
        {
          "time": "00:00",
          "timeAsSeconds": 0,
          "value": 105
        }
        // usually 3 or more entries per day
      ],
      "target_high": [
        {
          "time": "00:00",
          "timeAsSeconds": 0,
          "value": 110
        }
        // usually 3 or more entries per day
      ],
      "units": "mg/dl",
      "timezone": "Europe/Berlin"
    }
  },
  "identifier": "66fc77ebbad952399da1caa1",
  "srvModified": 1727821804761,
  "srvCreated": 1727821804761
}

```

---
#### Read

GET  https://ns.jensheuschkel.de/api/v3/profile/ `:identifier`

```json
{
  "status": 200,
  "result": {
    "defaultProfile": "Default",
    "store": {
      "Default": {
        "dia": 5,
        "carbratio": [
          {
            "time": "00:00",
            "value": 10,
            "timeAsSeconds": 0
          }
        ], // usually only 1–6 entries depending on the day
        "carbs_hr": 20,
        "delay": 20,
        "sens": [
          {
            "time": "00:00",
            "value": 30,
            "timeAsSeconds": 0
          }
        ], // may have multiple entries in tuned profiles
        "timezone": "Europe/Berlin",
        "basal": [
          {
            "time": "00:00",
            "value": 0.5,
            "timeAsSeconds": 0
          }
        ], // usually 24 hourly entries
        "target_low": [
          {
            "time": "00:00",
            "value": 90,
            "timeAsSeconds": 0
          }
        ], // 1–3 entries normally
        "target_high": [
          {
            "time": "00:00",
            "value": 120,
            "timeAsSeconds": 0
          }
        ], // 1–3 entries normally
        "startDate": "1970-01-01T00:00:00.000Z",
        "units": "mg/dl"
      }
    },
    "startDate": "1970-01-01T00:00:00.000Z",
    "mills": 0,
    "created_at": "2025-04-09T12:31:15.694Z",
    "srvModified": 1744201875694,
    "units": "mg/dl",
    "identifier": "67f667b423129088a7a913dd",
    "srvCreated": 1744201875694
  }
}
```

---
#### Create

POST https://ns.jensheuschkel.de/api/v3/profile
(Date can only exist once otherwise data gets overwritten!)

```json
{
	"date": 1745261261000,
	"app": "Test"
	// add any property you want
}
```


Schema:

| Field           | Type                              | Required            | Example                                | Description                                                                   |
| --------------- | --------------------------------- | ------------------- | -------------------------------------- | ----------------------------------------------------------------------------- |
| `identifier`    | `string`                          | Auto                | `53409478-105f-11e9-ab14-d663bd873d93` | **Server-assigned** unique ID. Used for deduplication and lookups. Immutable. |
| `date`          | `integer` (ms or s) or ISO string | Yes                 | `1525383610088`                        | Timestamp of event (auto-normalized to UTC). Immutable.                       |
| `utcOffset`     | `integer`                         | Optional            | `120`                                  | UTC offset in minutes (auto-parsed or manually set). Immutable.               |
| `app`           | `string`                          | Yes                 | `xdrip`                                | Source application or system. Immutable.                                      |
| `device`        | `string`                          | Optional            | `dexcom G5`                            | Origin device (e.g. sensor name). Immutable.                                  |
| `subject`       | `string`                          | Auto                | `uploader`                             | User or service that created the document. Immutable.                         |
| `modifiedBy`    | `string`                          | Auto                | `admin`                                | Last user who modified or deleted the document. Immutable.                    |
| `srvCreated`    | `integer`                         | Auto                | `1525383610088`                        | Server-side creation timestamp (ms). Immutable.                               |
| `srvModified`   | `integer`                         | Auto                | `1525383610088`                        | Server-side last modified timestamp (ms). Immutable.                          |
| `isValid`       | `boolean`                         | Auto (history only) | `false`                                | Marks document as deleted in history view. Immutable.                         |
| `isReadOnly`    | `boolean`                         | Optional            | `true`                                 | Locks the document from future updates or deletions. Immutable once set.      |
| `_id`           | `string`                          | Auto                | `58e9dfbc166d88cc18683aac`             | Internal Mongo `_id`. Not for API use.                                        |
| `some_property` | `string`                          | Optional            | —                                      | Placeholder for app-specific data.                                            |

---
#### Update (full overwrite)

PUT https://ns.jensheuschkel.de/api/v3/profile `:identifier`

```json
{
  "date": 1532936118000,
  "app": "xdrip"
  // any changes you wish to make
}
```

---

#### Patch (partial update)

PATCH https://ns.jensheuschkel.de/api/v3/profile `:identifier`

```json
{
  "date": 1532936118000,
  "app": "xdrip"
  // any changes you wish to make
}
```

---

#### Delete

DELETE https://ns.jensheuschkel.de/api/v3/profile/ `:identifier` /  `optional:permanent=true or false`