- [Kanban Board](https://kb.jensheuschkel.de)
- [Nightscout Test Instance](https://ns.jensheuschkel.de) `verysecureapisecret1`
- [Nightscout github repo](https://github.com/nightscout/cgm-remote-monitor)
- Nightscout admin token: admin-2d7f0f1241a33f74

Loopkit für apple
Nightscout reporter
1. AndroidAPS Interaktion mit NS observieren (Schreibt)
2. NSReporter Interaktion mit NS observieren (Liest)
3. Eigenen code schreiben der das emuliert
4. test

>AAPS hat ein virtual pump modul für fake daten, man kann es verwenden.